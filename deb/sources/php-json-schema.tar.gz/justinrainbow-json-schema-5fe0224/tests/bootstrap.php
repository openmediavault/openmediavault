<?php

require dirname(__FILE__) . '/../bootstrap.php';
require 'BaseTestCase.php';