<?php
class JsonSchemaUndefined {}
?>