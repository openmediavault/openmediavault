/*conf:+jscript_function_extensions*/

function conf.jscript_function_extensions:onunload(val) { /*warning:syntax_error*/
}
