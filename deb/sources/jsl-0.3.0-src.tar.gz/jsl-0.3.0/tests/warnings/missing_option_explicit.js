/*jsl:option explicit*/
function missing_option_explicit() {
    /* nothing to see here; move along */
    return null;
}
