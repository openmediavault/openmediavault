/*jsl:option explicit*/
function octal_number() {
    var i;
    i = 010; /*warning:octal_number*/
}
