/*jsl:option explicit*/
function jsl_cc_not_understood() {
    /*jsl:bogon*/ /*warning:jsl_cc_not_understood*/
    return;
}
