/*jsl:option explicit*/
function dup_option_explicit() {
    /*@option explicit@*/ /*warning:dup_option_explicit*/
    return null;
}
