/*jsl:option explicit*/
function duplicate_formal(duplicate,
                          duplicate) { /*warning:duplicate_formal*/
    return;
}
